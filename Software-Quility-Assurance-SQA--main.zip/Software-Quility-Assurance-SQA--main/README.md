# Software-Quility-Assurance(SQA)
Software quality assurance (SQA) is a process that ensures that developed software meets and complies with defined or standardized quality specifications. SQA is an ongoing process within the software development life cycle (SDLC) that routinely checks the developed software to ensure it meets desired quality measure.


*****Topics Covered*******
  *Test Case and Report writing "Mind Map with XMind 
  *API Manual Testing and Automation Testing with Postman and Newman 
  *Lood Testing with JMeter 
  *Database Testing
  *Security & Penetration Testing 
  *Agile & Jira
  *Java Basics
  *"Web Automation with Cypress "Web Automation with "Selenium" & other frameworks. 
  *Mobile application testing with "Applum" & Test project 
  *Mobile Manual Testing
  *"Cit & ICI/CDI Pipelines with Jenkins 
  *"SOA Freelancing" 
