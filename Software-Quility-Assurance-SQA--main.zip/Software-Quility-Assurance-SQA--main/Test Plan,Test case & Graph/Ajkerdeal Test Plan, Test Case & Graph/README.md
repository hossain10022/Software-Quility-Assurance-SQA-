Ajkerdeal test plan, case and graph
