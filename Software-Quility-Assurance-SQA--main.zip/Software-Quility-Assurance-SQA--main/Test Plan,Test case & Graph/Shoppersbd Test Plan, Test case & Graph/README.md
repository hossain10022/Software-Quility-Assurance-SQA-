Shoppersbd test plan, test case and graph
