Here,  API Testing Report NEWMAN .
