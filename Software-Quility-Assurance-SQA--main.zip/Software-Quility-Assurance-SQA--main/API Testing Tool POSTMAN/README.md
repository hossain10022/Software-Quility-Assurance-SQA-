API stands for Application Programming Interface. An API is a software intermediary that allows two applications to talk to each other. 
